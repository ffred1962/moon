import asyncio
import flet as ft
import os

_h1=1350000
_t1=0
_f1=13000
_v1=11000
_a=0
def main(page: ft.Page):
    def set_fields():
        # print(_h1)
        mins, secs = divmod(_t1, 60)
        ti_f.value="{:02d}:{:02d}".format(mins, secs)
        h1_f.value="{:,}".format(int(_h1))
        v1_f.value="{:,}".format(int(_v1))
        fuel_f.value="{:,}".format(_f1)
        a_f.value="{:.2f}".format(_a)
        page.update()
    
    async def landing():
        global _t1
        global _a
        global _f1
        global _v1
        global _h1
        
        async def init_game():
            global _t1
            global _a
            global _f1
            global _v1
            global _h1
            _h1=1350000
            _t1=0
            _f1=13000
            _v1=11000
            _a=0
            await  landing()

        def close_banner(e):
            page.window.destroy()
        async def try1(e):
            banner1.open=False
            page.update()
            await init_game()

            
        print("main loop")
        while _h1>=0:
            _t1+=1
            _h1-=_v1
            _a=-int(engine_f.value)+10/6
            if _f1>int(engine_f.value):
                _f1-=int(engine_f.value)
            else:
                _f1=0
                engine_f.value=0
                engine_f.disabled=True 
            _v1+=_a
            # print(_t1)
            set_fields()
            await asyncio.sleep(1)
        banner1 = ft.Banner(
            bgcolor=ft.Colors.AMBER_100,
            leading=ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, color=ft.Colors.AMBER, size=40),
            content=ft.Text(
                value="",
                color=ft.Colors.BLACK,
            ),
            actions=[
                ft.TextButton(text="Закрыть",  on_click=close_banner),
                ft.TextButton(text="Повторить",  on_click=try1),
                
            ]
            
        )
        page.add(banner1)
        if _v1 <= 5:
            txt="Поздравляем, Вы отлично справились с заданием!"
        if _v1 <= 20:
            txt="Вам удалось прилуниться, но корабль получил повреждения....  :("
        if _v1 > 20:
            txt="К сожланию Вы слишком быстро летели и Ваш корабль взорвался, а на луне образовался огромный кратер.... Его назвали в честь Вас"
        banner1.content=ft.Text(value=txt)
        banner1.open=True
        page.update()



    # print(page.platform)
    if page.platform == ft.PagePlatform.WINDOWS:
        page.window.width=300
        page.window.height=400

    page.title="Посаддка на луну"
    ti_f=ft.TextField(label="Время",  read_only=True, text_align=ft.TextAlign.RIGHT )
    h1_f=ft.TextField(label="Высота, м", read_only=True, text_align=ft.TextAlign.RIGHT )
    v1_f=ft.TextField(label="Скорость, м/с", read_only=True, text_align=ft.TextAlign.RIGHT )
    fuel_f=ft.TextField(label="Топливо, кг", read_only=True, text_align=ft.TextAlign.RIGHT )
    a_f=ft.TextField(label="Ускорение, м/с2", read_only=True, text_align=ft.TextAlign.RIGHT )
    engine_f=ft.Slider(min=0, max=50, divisions=50, label="{value}")
    page.add(
            ti_f,
            h1_f,
            v1_f,
            fuel_f,
            a_f,
            engine_f
    )
    set_fields()
    
    page.run_task(landing)

ft.app(main)


import asyncio
import flet as ft
import math

_h1=1350000
_t1=0
_f1=13000
_v1=11000
_a=0
def main(page: ft.Page):
    def set_fields():
        # print(_h1)
        mins, secs = divmod(_t1, 60)
        st2="{:02d}:{:02d}".format(mins, secs)
        st1="-:-"
        if _v1>0:
            t2=int(_h1/_v1)
            if t2<60:
                ti_f.color=ft.Colors.RED_900
            else:
                ti_f.color=ft.Colors.BLACK
            mins,secs=divmod(t2, 60)
            st1="{:02d}:{:02d}".format(mins, secs)
        ti_f.value= st2+"  /  " + st1
        h1_f.value="{:,}".format(int(_h1))
        if _h1<1000:
            h1_f.color=ft.Colors.RED_900
        else:
            h1_f.color=ft.Colors.BLACK
        st1="{:,}".format(int(_v1))
        st2=" - "
        if _a<0:
            v2=math.sqrt(-2*_a*_h1)
            st2="{:,}".format(int(v2))
        v1_f.value=st1+ "  /  "+st2
        if _f1<1000:
            fuel_f.color=ft.Colors.RED_900
        else:
            fuel_f.color=ft.Colors.BLACK
        fuel_f.value="{:,}".format(_f1)
        st1="{:.2f}".format(_a)
        st2=" - "
        if _v1>0 and _h1>0:
            a1=-(_v1*_v1)/(2*_h1)
            st2= "{:.2f}".format(a1)
        a_f.value=st1+"  /  "+st2
        page.update()
    
    async def landing():
        global _t1
        global _a
        global _f1
        global _v1
        global _h1
        
        async def init_game():
            global _t1
            global _a
            global _f1
            global _v1
            global _h1
            _h1=1350000
            _t1=0
            _f1=13000
            _v1=11000
            _a=0
            engine_f.value=0
            engine_f.disabled=False
            await  landing()

        def close_banner(e):
            page.window.destroy()
        async def try1(e):
            banner1.open=False
            page.update()
            await init_game()

            
        print("main loop")
        while _h1>0:
            _t1+=1
            if _h1> _v1:
                _h1-=_v1
            else:
                _h1=0
            _a=-int(engine_f.value)+10/6
            if _f1>int(engine_f.value):
                _f1-=int(engine_f.value)
            else:
                _f1=0
                engine_f.value=0
                engine_f.disabled=True 
            _v1+=_a
            if _v1<0:
                engine_f.value=0
            if engine_f.value>0 and engine_f.value<5:
                engine_f.max=5
            if engine_f.value >=5:
                engine_f.max=50
            # print(_t1)
            set_fields()
            await asyncio.sleep(1)
        banner1 = ft.Banner(
            bgcolor=ft.Colors.AMBER_100,
            leading=ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, color=ft.Colors.AMBER, size=40),
            content=ft.Text(
                value="",
                color=ft.Colors.BLACK,
            ),
            actions=[
                ft.TextButton(text="Закрыть",  on_click=close_banner),
                ft.TextButton(text="Повторить",  on_click=try1),
                
            ]
            
        )
        page.add(banner1)
        if _v1 <= 5:
            txt="Поздравляем, Вы отлично справились с заданием!"
            banner1.leading=ft.Icon(ft.icons.COFFEE_ROUNDED,color=ft.colors.GREEN_100, size=40)
        elif _v1 <= 20:
            txt="Вам удалось прилуниться, но корабль получил повреждения....  :("
        else:
            txt="К сожланию Вы слишком быстро летели и Ваш корабль взорвался, а на луне образовался огромный кратер.... Его назвали в честь Вас"
        banner1.content=ft.Text(value=txt)
        banner1.open=True
        page.update()



    # print(page.platform)
    if page.platform == ft.PagePlatform.WINDOWS:
        page.window.width=300
        page.window.height=400

    page.title="Посаддка на луну"
    ti_f=ft.TextField(label="Время",  read_only=True, text_align=ft.TextAlign.RIGHT )
    h1_f=ft.TextField(label="Высота, м", read_only=True, text_align=ft.TextAlign.RIGHT )
    v1_f=ft.TextField(label="Скорость, м/с", read_only=True, text_align=ft.TextAlign.RIGHT )
    fuel_f=ft.TextField(label="Топливо, кг", read_only=True, text_align=ft.TextAlign.RIGHT )
    a_f=ft.TextField(label="Ускорение, м/с2", read_only=True, text_align=ft.TextAlign.RIGHT )
    engine_f=ft.Slider(min=0, max=50, divisions=50, label="{value}")
    page.add(
            ti_f,
            h1_f,
            v1_f,
            fuel_f,
            a_f,
            engine_f
    )
    set_fields()
    
    page.run_task(landing)

ft.app(main)

